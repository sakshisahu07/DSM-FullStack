import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    firstName: {
      type: String,
      trim: true,
    },
    lastName: {
      type: String,
      trim: true,
    },

    email: {
      type: String,
      trim: true,
    },

    image: {
      type: String,
      default: "",
    },

    password: {
      type: String,
    },

    number: {
      type: String,
      trim: true,
    },

    fcmToken: {
      type: String,
      trim: true,
    },

    address: {
      type: mongoose.Schema.ObjectId,
      ref: "address",
    },

    role: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Role",
    },

    otp: {
      code: String,
      expiresAt: Date,
    },
    disable: {
      type: Boolean,
      default: false,
    },

    fcmToken: {
      type: String,
    },
    permissions: [
      {
        type: String,
      },
    ],
    companyName: {
      type: String,
      trim: true,

    },
    companyGstNo: {
      type: String,
      trim: true,
    },

    walletBalance: {
      type: Number,
      default: 0,
      min: 0,
    },
    referralCode: {
      type: String,
      sparse: true,
      unique: true,
    },
    referredBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
      default: null,
    },
    isReferralRewardGiven: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true },
);

const userModel = mongoose.model("user", userSchema);

export default userModel;
